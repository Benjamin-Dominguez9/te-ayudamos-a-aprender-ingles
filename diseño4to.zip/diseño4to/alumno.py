class Alumno:
    def __init__(self, nombre, nota):
        self.nombre = nombre
        self.nota = nota

    def imprimir_datos(self):
        print(f"Nombre: {self.nombre}")
        print(f"Nota: {self.nota}")

    def evaluar(self):
        if self.nota >= 6:
            resultado = "Aprobado"
        else:
            resultado = "No aprobado"
        print(f"{self.nombre} ha {resultado} con una nota de {self.nota}.")

# Ejemplo de uso
def main():
    # Crear instancias de la clase Alumno
    alumno1 = Alumno("Mario", 8)
    alumno2 = Alumno("Brunela", 3.5)

    # Imprimir datos y evaluar a los alumnos
    alumno1.imprimir_datos()
    alumno1.evaluar()

    alumno2.imprimir_datos()
    alumno2.evaluar()

if __name__ == "__main__":
    main()
